#!/usr/bin/python

from service import *

print "DING"

runservice()